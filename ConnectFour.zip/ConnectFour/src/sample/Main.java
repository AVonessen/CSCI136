package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.geometry.*;

import javafx.scene.text.Text;


public class Main extends Application {
    public static int turn = 1;
    public static boolean done = false;
    public static char winner = ' ';
    public static String winMessage = "";
    public static char[][] c = new char[5][6];
    public static void main(String[] args) {
        launch(args);
    } //end main
    public static GridPane grid = new GridPane();
    public static Label turnMess = new Label("Pink's turn");

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Play Connect Four!");

        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Scene scene = new Scene(grid, 300, 275);
        primaryStage.setScene(scene);
        scene.getStylesheets().add(Main.class.getResource("style.css").toExternalForm());


        Text scenetitle = new Text(" ");
        scenetitle.setId("welcome-text");
        grid.add(scenetitle, 0, 0, 3, 1);


        for (int i = 0; i < 6; i++) {
            for (int j = 1; j < 6; j++) {
                grid.add(createButton(), i, j);
            }
        }

        turnMess = new Label("Pink's turn");
        grid.add(turnMess, 0, 7, 3, 1);

        Text endMessage = new Text(winMessage);
        endMessage.setId("uhhh");
        grid.add(endMessage, 0, 0, 6, 1);

        primaryStage.show();
    }

    public static void changeWinMessage() {
        if (winner != ' ' & turn > 30) {
            if (winner == 'X'){
                winMessage = ("Pink won!");
            }
            else{
                winMessage = ("Blue won!");
            }

        }
        else if (turn > 30) {
            winMessage = ("Players tied!");
        }

        Text endMessage = new Text(winMessage);
        endMessage.setId("uhhh");
        grid.add(endMessage, 0, 0, 3, 1);
        if(done){
            turnMess.setText(" ");
            //it would be great if we could deactivate all buttons
        }
    }
    public static void checkWinConditions() {
        //so, set up a char array c, 5 by 6, that fills in each location
        //as each button is pressed. this should check to see if
        //horizontal wins
        for(int i = 0; i < 5; i++) {
            for(int j = 0; j < 3; j++){
                if (c[i][j] == c[i][j+1] & c[i][j] == c[i][j+2] & c[i][j] == c[i][j+3] & c[i][j] != 0 ) {
                    System.out.println("Player " + c[i][j] + " wins");
                    done = true;
                    winner = c[i][j];
                    turn = 35;
                }
            }
        }
        //vertical wins
        for(int i = 0; i < 2; i++) {
            for(int j = 0; j < 6; j++){
                if (c[i][j] == c[i+1][j] & c[i][j] == c[i+2][j] & c[i][j] == c[i+3][j] & c[i][j] != 0 ) {
                    System.out.println("Player " + c[i][j] + " wins");
                    done = true;
                    winner = c[i][j];
                    turn = 35;
                }
            }
        }
        //diagonal to the right
        for(int i = 0; i < 2; i++) {
            for(int j = 0; j < 3; j++){
                if (c[i][j] == c[i+1][j+1] & c[i][j] == c[i+2][j+2] & c[i][j] == c[i+3][j+3] & c[i][j] != 0 ) {
                    System.out.println("Player " + c[i][j] + " wins");
                    done = true;
                    winner = c[i][j];
                    turn = 35;
                }
            }
        }
        //diagonal to the left
        for(int i = 0; i < 2; i++) {
            for(int j = 3; j < 6; j++){
                if (c[i][j] == c[i+1][j-1] & c[i][j] == c[i+2][j-2] & c[i][j] == c[i+3][j-3] & c[i][j] != 0 ) {
                    System.out.println("Player " + c[i][j] + " wins");
                    done = true;
                    winner = c[i][j];
                    turn = 35;
                }
            }
        }

    }

    private static Button createButton() {
        //instantiates button objects with the same properties
        Button b = new Button("  ");
        b.setStyle(
                "-fx-background-radius: 5em; " +
                "-fx-min-width: 25px; " +
                "-fx-min-height: 25px; " +
                "-fx-max-width: 25px; " +
                "-fx-max-height: 25px;"
        );
        b.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                int row = GridPane.getRowIndex(b) - 1;
                int col = GridPane.getColumnIndex(b);

                if (row==4) {
                    //implement Tic Tac Toe logic
                    if (done){}
                    else if(turn % 2 != 0) {
                        b.setId("orangepink");
                        b.setText("");
                        c[row][col] = 'X';
                        b.setDisable(true);

                        turnMess.setText("Blue's turn");
                    }
                    else {
                        b.setId("greenblue");
                        b.setText("");
                        c[row][col] = 'O';
                        b.setDisable(true);

                        turnMess.setText("Pink's turn");
                    }
                }
                else if (c[row+1][col] != 0) {
                    //implement Tic Tac Toe logic
                    if (done) {
                    }
                    else if (turn % 2 != 0) {
                        b.setId("orangepink");
                        b.setText("");
                        c[row][col] = 'X';
                        b.setDisable(true);

                        turnMess.setText("Blue's turn");
                    }
                    else {
                        b.setId("greenblue");
                        b.setText("");
                        c[row][col] = 'O';
                        b.setDisable(true);

                        turnMess.setText("Pink's turn");
                    }
                }
                else{
                    System.out.println("no.");
                    turn=turn-1;
                }

                //outputs to the terminal
                System.out.println("Turn = " + turn + " Row = " + row + " Col = " + col);
                //b.setDisable(true); //after button is clicked, disable it
                // call method to check for winner
                turn++;
                checkWinConditions();
                changeWinMessage();
            }
        });
        return b;
    }
}

